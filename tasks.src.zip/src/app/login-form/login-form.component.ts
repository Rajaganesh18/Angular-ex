import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent {

  @ViewChild('loginForm') loginForm!: NgForm;

  user = {
    username: '',
    password: ''
  };

  loginSuccess = false;
  loginError: string | null = null;
  loginAttempts = 0;
  maxAttempts = 3;

  onSubmit() {
    // Simulate authentication logic (replace this with your actual authentication logic)
    const validUsername = 'Raja';
    const validPassword = 'pass';

    if (this.user.username === validUsername && this.user.password === validPassword) {
      this.loginSuccess = true;
      this.loginError = null;
    } else {
      this.loginAttempts++;
      this.loginSuccess = false;
      this.loginError = "Invalid credentials";

      if (this.loginAttempts >= this.maxAttempts) {
        // Disable the form after max attempts
        // You might want to redirect or take additional actions here
        this.loginForm.form.disable();
      }
    }
  }
}    