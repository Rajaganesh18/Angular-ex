import { Component } from '@angular/core';

@Component({
  selector: 'app-color-changer',
  templateUrl: './color-changer.component.html',
  styleUrls: ['./color-changer.component.css']
})
export class ColorChangerComponent {
  colorValue: string = ''; // Initialize with an empty string

  changeColor() {
    // This method is called when the input value changes
    // You can add validation or other logic here if needed
  }
}
