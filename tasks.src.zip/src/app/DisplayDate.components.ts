import { Component } from '@angular/core';

@Component({
  selector: 'my-samp-date',
  template: `<p> date is {{ result }} </p>`,
})
export class DisplayDate {
  result: string;
  constructor() {
    var d = new Date();
    this.result = d.toString();
  }
}
