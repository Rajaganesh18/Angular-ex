import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortCountries',
})
export class SortCountriesPipe implements PipeTransform {
  transform(countries: string[], order: 'asc' | 'desc'): string[] {
    if (!countries || countries.length <= 1) {
      return countries;
    }

    if (order === 'asc') {
      return countries.slice().sort();
    } else if (order === 'desc') {
      return countries.slice().sort().reverse();
    }

    return countries;
  }
}

