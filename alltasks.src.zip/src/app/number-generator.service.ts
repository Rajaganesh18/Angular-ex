// number-generator.service.ts
import { Injectable } from '@angular/core';
import { Subject, Observable, interval } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class NumberGeneratorService {
  private oddNumberSubject = new Subject<number>();
  private evenNumberSubject = new Subject<number>();
  private oddNumberInterval: any;
  private evenNumberInterval: any;

  startOddNumberGenerator(): void {
    this.oddNumberInterval = setInterval(() => {
      const oddNumber = this.generateOddNumber();
      this.oddNumberSubject.next(oddNumber);
    }, 1000);
  }

  stopOddNumberGenerator(): void {
    clearInterval(this.oddNumberInterval);
  }

  startEvenNumberGenerator(): void {
    this.evenNumberInterval = setInterval(() => {
      const evenNumber = this.generateEvenNumber();
      this.evenNumberSubject.next(evenNumber);
    }, 1000);
  }

  stopEvenNumberGenerator(): void {
    clearInterval(this.evenNumberInterval);
  }

  getOddNumbers(): Observable<number> {
    return this.oddNumberSubject.asObservable();
  }

  getEvenNumbers(): Observable<number> {
    return this.evenNumberSubject.asObservable();
  }

  private generateOddNumber(): number {
    return Math.floor(Math.random() * 50) * 2 + 1;
  }

  private generateEvenNumber(): number {
    return Math.floor(Math.random() * 50) * 2;
  }
}
