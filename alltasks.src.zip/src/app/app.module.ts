import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { ReadonlyDirective } from './readonly.directive';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OddComponent } from './odd/odd.component';
import { EvenComponent } from './even/even.component';
import { MainComponent } from './main/main.component';
import { ReverseStringPipe } from './reverse-string.pipe';
import { CountryListComponent } from './country-list/country-list.component';
import { SortCountriesPipe } from './sort-countries.pipe';
import { TemperatureConversionPipe } from './temperature-conversion.pipe';
import { NoWhiteSpaceDirective } from './no-white-space.directive';
import { NumbersOnlyDirective } from './numbers-only.directive';
import { NumberSymbol } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    OddComponent,
    EvenComponent,
    MainComponent,
    ReverseStringPipe,
    CountryListComponent,
    SortCountriesPipe,
    TemperatureConversionPipe,
    ReadonlyDirective,
    NoWhiteSpaceDirective,
    NumbersOnlyDirective
  ],
  exports: [
    ReverseStringPipe,
    SortCountriesPipe,
    TemperatureConversionPipe,
    ReadonlyDirective,
    NoWhiteSpaceDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
