// even.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NumberGeneratorService } from '../number-generator.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-even',
  templateUrl: './even.component.html',
  styleUrls: ['./even.component.css'],
})
export class EvenComponent implements OnInit, OnDestroy {
  evenNumbers: number[] = [];
  private evenNumbersSubscription!: Subscription;

  constructor(private numberGeneratorService: NumberGeneratorService) {}

  ngOnInit(): void {
    this.evenNumbersSubscription = this.numberGeneratorService
      .getEvenNumbers()
      .subscribe((number) => {
        this.evenNumbers.push(number);
      });
  }

  ngOnDestroy(): void {
    this.evenNumbersSubscription.unsubscribe();
  }
}
