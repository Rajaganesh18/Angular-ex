// main.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NumberGeneratorService } from '../number-generator.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
})
export class MainComponent implements OnInit, OnDestroy {
  oddNumbers: number[] = [];
  evenNumbers: number[] = [];
  private oddNumbersSubscription!: Subscription;
  private evenNumbersSubscription!: Subscription;

  constructor(private numberGeneratorService: NumberGeneratorService) {}

  ngOnInit(): void {}

  ngOnDestroy(): void {
    this.stopGenerators();
  }

  startGenerators(): void {
    this.startOddNumberGenerator();
    this.startEvenNumberGenerator();
  }

  stopGenerators(): void {
    this.numberGeneratorService.stopOddNumberGenerator();
    this.numberGeneratorService.stopEvenNumberGenerator();
    this.oddNumbersSubscription.unsubscribe();
    this.evenNumbersSubscription.unsubscribe();
  }

  private startOddNumberGenerator(): void {
    this.numberGeneratorService.startOddNumberGenerator();
    this.oddNumbersSubscription = this.numberGeneratorService
      .getOddNumbers()
      .subscribe((number) => {
        this.oddNumbers.push(number);
      });
  }

  private startEvenNumberGenerator(): void {
    this.numberGeneratorService.startEvenNumberGenerator();
    this.evenNumbersSubscription = this.numberGeneratorService
      .getEvenNumbers()
      .subscribe((number) => {
        this.evenNumbers.push(number);
      });
  }
}
