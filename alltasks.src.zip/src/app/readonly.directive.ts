// readonly.directive.ts
import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appReadonly]'
})
export class ReadonlyDirective {

  constructor(private el: ElementRef) { }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    // Prevent any keyboard input (e.g., typing)
    event.preventDefault();
  }

  @HostListener('paste', ['$event'])
  onPaste(event: ClipboardEvent) {
    // Prevent pasting into the textbox
    event.preventDefault();
  }

  @HostListener('focus', ['$event'])
  onFocus(event: FocusEvent) {
    // Disable focus on the element
    event.preventDefault();
    this.el.nativeElement.blur();
  }
}
