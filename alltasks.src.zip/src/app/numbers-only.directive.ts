// numbers-only.directive.ts
import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appNumbersOnly]'
})
export class NumbersOnlyDirective {
  @Input() allowDecimal: boolean = false;

  constructor(private el: ElementRef) {}

  @HostListener('input', ['$event'])
  onInput(event: InputEvent): void {
    const inputElement = this.el.nativeElement as HTMLInputElement;
    const inputValue = inputElement.value;

    // Allow only numbers and optionally a decimal point
    const regex = this.allowDecimal ? /^[0-9]*\.?[0-9]*$/ : /^[0-9]*$/;
    
    if (!regex.test(inputValue)) {
      // Remove non-numeric characters
      inputElement.value = inputValue.replace(/[^0-9\.]/g, '');
    }
  }
}
