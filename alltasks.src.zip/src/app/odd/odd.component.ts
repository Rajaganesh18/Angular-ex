// odd.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NumberGeneratorService } from '../number-generator.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-odd',
  templateUrl: './odd.component.html',
  styleUrls: ['./odd.component.css'],
})
export class OddComponent implements OnInit, OnDestroy {
  oddNumbers: number[] = [];
  private oddNumbersSubscription!: Subscription;

  constructor(private numberGeneratorService: NumberGeneratorService) {}

  ngOnInit(): void {
    this.oddNumbersSubscription = this.numberGeneratorService
      .getOddNumbers()
      .subscribe((number) => {
        this.oddNumbers.push(number);
      });
  }

  ngOnDestroy(): void {
    this.oddNumbersSubscription.unsubscribe();
  }
}
