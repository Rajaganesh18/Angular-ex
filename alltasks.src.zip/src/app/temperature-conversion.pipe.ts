// temperature-conversion.pipe.ts
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'temperatureConversion'
})
export class TemperatureConversionPipe implements PipeTransform {
  transform(value: number, fromUnit: string, toUnit: string): number {
    if (fromUnit === 'Celsius' && toUnit === 'Fahrenheit') {
      return (value * 9/5) + 32;
    } else if (fromUnit === 'Fahrenheit' && toUnit === 'Celsius') {
      return (value - 32) * 5/9;
    } else {
      return value; // Return unchanged value if units are the same or unknown
    }
  }
}
