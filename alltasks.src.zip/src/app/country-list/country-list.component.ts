import { Component } from '@angular/core';
import { SortCountriesPipe } from '../sort-countries.pipe';


@Component({
  selector: 'app-country-list',
  templateUrl: './country-list.component.html',
  styleUrls: ['./country-list.component.css'],
})
export class CountryListComponent {
  countries: string[] = ['USA', 'Canada', 'Australia', 'India', 'Germany'];
}
