import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-tasks';
  myString: string = 'Hello, World!';
  countries = ['France', 'Germany', 'Spain', 'Italy', 'United Kingdom']
}
