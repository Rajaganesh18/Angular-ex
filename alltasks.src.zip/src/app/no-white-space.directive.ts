// no-white-space.directive.ts
import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appNoWhiteSpace]'
})
export class NoWhiteSpaceDirective {

  constructor() { }

  @HostListener('input', ['$event'])
  onInput(event: InputEvent): void {
    const inputElement = event.target as HTMLInputElement;
    const inputValue = inputElement.value;
    
    // Remove whitespaces from the input value
    const newValue = inputValue.replace(/\s/g, '');
    
    // Update the input value without whitespaces
    inputElement.value = newValue;
  }
}
